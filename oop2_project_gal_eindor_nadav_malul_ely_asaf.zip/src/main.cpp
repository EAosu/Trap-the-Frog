#include "Controller.h"

int main()
{

	auto game = Controller();
	game.run();

	return EXIT_SUCCESS;
}
